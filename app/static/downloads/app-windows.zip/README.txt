BarberKing Desktop Application v1.0
==================================

Installation Instructions:
1. Extract this ZIP file
2. Run the installer
3. Follow the setup wizard

System Requirements:
- Windows 7 or later
- 100 MB free disk space
- .NET Framework 4.5+

For support, visit: https://barberking.com/support
