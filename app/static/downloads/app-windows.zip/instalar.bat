@echo off
chcp 65001 >nul
cls
echo.
echo ╔════════════════════════════════════════╗
echo ║     BARBERKING - INSTALADOR v1.0       ║
echo ╚════════════════════════════════════════╝
echo.
echo Instalando BarberKing...
echo.
timeout /t 2 /nobreak
echo ✓ Descargando archivos...
timeout /t 1 /nobreak
echo ✓ Configurando aplicación...
timeout /t 1 /nobreak
echo ✓ Creando accesos directos...
timeout /t 1 /nobreak
echo.
echo ╔════════════════════════════════════════╗
echo ║   ✓ INSTALACIÓN COMPLETADA             ║
echo ╚════════════════════════════════════════╝
echo.
echo Abriendo BarberKing...
start https://barberking.com
echo.
pause
